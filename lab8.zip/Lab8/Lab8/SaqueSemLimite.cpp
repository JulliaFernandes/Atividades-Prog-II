#include "SaqueSemLimite.hpp"

using namespace std;

SaqueSemLimite :: SaqueSemLimite():
    runtime_error("\nVOCE ULTRAPASSOU O SEU SALDO\n")
{
}